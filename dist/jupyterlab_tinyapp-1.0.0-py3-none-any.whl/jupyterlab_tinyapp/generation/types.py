from typing import TypedDict, Optional

class ParsedContent(TypedDict):
    desc: Optional[str]
    code: Optional[str]
    deps: Optional[str]
    notes: Optional[str]
    retry: Optional[str]

# TODO: consider types that are used across typescript and python 
# TODO: for example: GenerateData