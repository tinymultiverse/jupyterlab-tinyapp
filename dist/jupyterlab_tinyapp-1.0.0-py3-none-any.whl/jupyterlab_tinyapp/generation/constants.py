from enum import Enum

# Constants for stream markers
DEPS_START_MARKER = "<<deps>>"
DEPS_END_MARKER = "<</deps>>"

# Enum for stream destinations
class StreamDestination(Enum):
    NOTEBOOK = "notebook"
    REQUIREMENTS = "requirements"