"use strict";
(self["webpackChunk_jupyterlab_tinyapp"] = self["webpackChunk_jupyterlab_tinyapp"] || []).push([["lib_index_js"],{

/***/ "./lib/components/AppCard.js":
/*!***********************************!*\
  !*** ./lib/components/AppCard.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppCard: () => (/* binding */ AppCard)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_LinearProgress__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @material-ui/core/LinearProgress */ "./node_modules/@material-ui/core/esm/LinearProgress/LinearProgress.js");
/* harmony import */ var _material_ui_icons_Launch__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/icons/Launch */ "./node_modules/@material-ui/icons/Launch.js");
/* harmony import */ var _material_ui_icons_DeleteForever__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/icons/DeleteForever */ "./node_modules/@material-ui/icons/DeleteForever.js");
/* harmony import */ var _material_ui_icons_MenuBook__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/icons/MenuBook */ "./node_modules/@material-ui/icons/MenuBook.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! moment */ "webpack/sharing/consume/default/moment/moment");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _middleware__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../middleware */ "./lib/middleware.js");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ "webpack/sharing/consume/default/@material-ui/core/@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../style/styles */ "./lib/style/styles.js");
/* harmony import */ var _components_CopyButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/CopyButton */ "./lib/components/CopyButton.js");
/* harmony import */ var _utils_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils/common */ "./lib/utils/common.js");











const AppCard = (props) => {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    const classes = (0,_style_styles__WEBPACK_IMPORTED_MODULE_3__.useStyles)();
    const { app, handleLogsButtonClick, handleDelete } = props;
    const [errorMessage, setErrorMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [deleteErrorMessage, setDeleteErrorMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [isDeleting, setIsDeleting] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    var isWaitCancelled = false;
    const maxWaitTime = 15 * 60 * 1000; // 15 minutes
    const pingInterval = 7 * 1000; // 7 seconds
    // Pings the app url
    const ping = async (url) => {
        return new Promise(resolve => {
            (0,_middleware__WEBPACK_IMPORTED_MODULE_4__.requestAPI)('ping', {
                body: JSON.stringify({
                    url: url
                }),
                method: 'POST'
            })
                .then(result => result.data)
                .then(result => resolve(result.ok));
        });
    };
    const loadingTimeout = (t0, maxMilliseconds) => {
        const tn = new Date();
        const timeDeltaMilliseconds = tn.getTime() - t0.getTime();
        return timeDeltaMilliseconds > maxMilliseconds;
    };
    const waitForAppStart = async (appUrl) => {
        const t0 = new Date();
        let ok = false;
        while (true) {
            if (loadingTimeout(t0, maxWaitTime)) {
                console.log('max wait time reached');
                setErrorMessage('App is taking too long to start. Please check logs.');
                break;
            }
            if (isWaitCancelled) {
                console.log('wait is cancelled');
                break;
            }
            console.log('pinging: ' + ok.toString());
            ok = await ping(appUrl);
            console.log('ready: ' + ok.toString());
            if (ok === true) {
                break;
            }
            await (0,_utils_common__WEBPACK_IMPORTED_MODULE_5__.delay)(pingInterval);
        }
        setIsLoading(false);
        console.log('app is ready');
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        var _a;
        waitForAppStart((_a = app.appRelease) === null || _a === void 0 ? void 0 : _a.appUrl);
        return function cleanup() {
            isWaitCancelled = true;
        };
    }, []);
    const handleDeleteButtonClick = async () => {
        var _a, _b;
        if (window.confirm('Are you sure you want to delete this app? It cannot be undone.')) {
            setErrorMessage('');
            setDeleteErrorMessage('');
            setIsDeleting(true);
            try {
                await (0,_middleware__WEBPACK_IMPORTED_MODULE_4__.requestAPI)('delete_app', {
                    body: JSON.stringify({
                        appId: (_a = app.appRelease) === null || _a === void 0 ? void 0 : _a.id
                    }),
                    method: 'POST'
                });
            }
            catch (error) {
                console.log('error deleting app:', error);
                setDeleteErrorMessage('Failed to delete app.');
                return;
            }
            finally {
                setIsDeleting(false);
            }
            handleDelete((_b = app.appRelease) === null || _b === void 0 ? void 0 : _b.id);
        }
    };
    const actions = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.CardActions, null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Button, { href: (_a = app.appRelease) === null || _a === void 0 ? void 0 : _a.appUrl, target: '_blank', disabled: isLoading || isDeleting || errorMessage != '' },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_icons_Launch__WEBPACK_IMPORTED_MODULE_6__["default"], { fontSize: 'small' }),
            "\u00A0View"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_CopyButton__WEBPACK_IMPORTED_MODULE_7__.CopyButton, { disabled: isDeleting, copyText: (_b = app.appRelease) === null || _b === void 0 ? void 0 : _b.appUrl }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Button, { disabled: isDeleting, onClick: () => { var _a, _b; return handleLogsButtonClick((_a = app.appDetail) === null || _a === void 0 ? void 0 : _a.name, (_b = app.appRelease) === null || _b === void 0 ? void 0 : _b.id); } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_icons_MenuBook__WEBPACK_IMPORTED_MODULE_8__["default"], { fontSize: 'small' }),
            "\u00A0Logs"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Button, { disabled: isDeleting, onClick: async () => await handleDeleteButtonClick() },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_icons_DeleteForever__WEBPACK_IMPORTED_MODULE_9__["default"], { fontSize: 'small' }),
            "\u00A0Delete")));
    const title = ((_c = app.appDetail) === null || _c === void 0 ? void 0 : _c.name) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Typography, { variant: 'h5', component: 'h2', style: { paddingBottom: '10px' } }, (_d = app.appDetail) === null || _d === void 0 ? void 0 : _d.name));
    const creationTime = ((_e = app.appRelease) === null || _e === void 0 ? void 0 : _e.creationTimeStamp) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { key: 'Creation Time', className: classes.valuePairContainer },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Typography, { className: classes.valuePairLabel },
            'Creation Time',
            "\u00A0"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Typography, { className: classes.valuePairValue }, moment__WEBPACK_IMPORTED_MODULE_1___default()((_f = app.appRelease) === null || _f === void 0 ? void 0 : _f.lastUpdateTimeStamp).format('lll'))));
    // TODO Show author once integrated with oauth or ldap
    // const author = (
    //   <span key={'author'} className={classes.valuePairContainer}>
    //     <Typography className={classes.valuePairLabel}>{'Author'}&nbsp;</Typography>
    //     <Typography className={classes.valuePairValue}>{app.appRelease?.appCreatorUserId}</Typography>
    //   </span>
    // );
    const description = ((_g = app.appDetail) === null || _g === void 0 ? void 0 : _g.description) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Typography, { style: { paddingTop: '20px' }, className: classes.valuePairValue, color: 'textPrimary' }, (_h = app.appDetail) === null || _h === void 0 ? void 0 : _h.description));
    const progressBar = !errorMessage && (isLoading || isDeleting) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { paddingTop: '20px' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_LinearProgress__WEBPACK_IMPORTED_MODULE_10__["default"], { classes: { colorPrimary: classes.colorPrimary, barColorPrimary: classes.barColorPrimary } })));
    const error = (errorMessage || deleteErrorMessage) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Typography, { color: 'error', style: { paddingTop: '20px' } }, errorMessage ? errorMessage : deleteErrorMessage));
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Card, { className: classes.appCard, variant: 'outlined' },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.CardContent, null,
            title,
            creationTime,
            description,
            progressBar,
            error),
        actions));
};


/***/ }),

/***/ "./lib/components/Common.js":
/*!**********************************!*\
  !*** ./lib/components/Common.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IframeContainer: () => (/* binding */ IframeContainer),
/* harmony export */   LoadingView: () => (/* binding */ LoadingView),
/* harmony export */   ResultContainer: () => (/* binding */ ResultContainer),
/* harmony export */   StyledTextInputField: () => (/* binding */ StyledTextInputField)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ "webpack/sharing/consume/default/@material-ui/core/@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../style/theme */ "./lib/style/theme.js");
/* harmony import */ var _style_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../style/styles */ "./lib/style/styles.js");





const StyledTextInputField = (0,_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.styled)(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.TextField)({
    paddingBottom: '20px',
    '& .MuiInput-underline:after': {
        borderBottom: `1px solid ${_style_theme__WEBPACK_IMPORTED_MODULE_3__.theme.palette.primary.main}`,
        transition: 'none'
    },
    '& .MuiInput-underline:hover:before': {
        borderBottom: '1px solid rgba(0, 0, 0, 0.42)'
    }
});
const IframeContainer = (props) => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("iframe", { style: { height: '100%', width: '100%' }, src: props.url, title: props.title }));
};
const LoadingView = (props) => {
    const classes = (0,_style_styles__WEBPACK_IMPORTED_MODULE_4__.useStyles)();
    const { viewType } = props;
    const spinner = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Spinner();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: viewType === 1 /* ViewType.MAIN */ ? classes.mainView : classes.partialView },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "loading-spinner", dangerouslySetInnerHTML: { __html: spinner.node.innerHTML } })));
};
const ResultContainer = (props) => {
    const classes = (0,_style_styles__WEBPACK_IMPORTED_MODULE_4__.useStyles)();
    const { viewType, resultType, title, message } = props;
    const containerClass = resultType === 1 /* ResultType.SUCCESS */
        ? classes.successContainer
        : classes.errorContainer;
    const viewClass = viewType === 1 /* ViewType.MAIN */ ? classes.mainView : classes.partialView;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `${containerClass} ${viewClass}` },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Typography, { component: "h5", variant: "h5" }, title),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Typography, { component: "h6", variant: "h6" }, message)));
};


/***/ }),

/***/ "./lib/components/CopyButton.js":
/*!**************************************!*\
  !*** ./lib/components/CopyButton.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CopyButton: () => (/* binding */ CopyButton)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "webpack/sharing/consume/default/@material-ui/core/@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clipboard_copy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! clipboard-copy */ "webpack/sharing/consume/default/clipboard-copy/clipboard-copy");
/* harmony import */ var clipboard_copy__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clipboard_copy__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_icons_FileCopy__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/icons/FileCopy */ "./node_modules/@material-ui/icons/FileCopy.js");




const CopyButton = (props) => {
    const { copyText, disabled } = props;
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
    const handleOpen = async () => {
        setOpen(true);
        await new Promise(resolve => setTimeout(resolve, 2000));
        setOpen(false);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { open: open, onOpen: handleOpen, disableFocusListener: true, disableHoverListener: true, disableTouchListener: true, title: "Copied!" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Button, { disabled: disabled, onClick: () => {
                clipboard_copy__WEBPACK_IMPORTED_MODULE_2___default()(copyText);
                handleOpen();
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_icons_FileCopy__WEBPACK_IMPORTED_MODULE_3__["default"], { fontSize: "small" }),
            "\u00A0Copy Link")));
};


/***/ }),

/***/ "./lib/components/Logs.js":
/*!********************************!*\
  !*** ./lib/components/Logs.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LogsDisplay: () => (/* binding */ LogsDisplay)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "webpack/sharing/consume/default/@material-ui/core/@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prismjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prismjs */ "webpack/sharing/consume/default/prismjs/prismjs");
/* harmony import */ var prismjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prismjs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_styles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../style/styles */ "./lib/style/styles.js");
/* harmony import */ var _Common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Common */ "./lib/components/Common.js");
/* harmony import */ var _style_base_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../style/base.css */ "./style/base.css");
/* harmony import */ var prismjs_components_prism_log__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prismjs/components/prism-log */ "./node_modules/prismjs/components/prism-log.js");
/* harmony import */ var prismjs_components_prism_log__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prismjs_components_prism_log__WEBPACK_IMPORTED_MODULE_4__);







const LogsDisplay = (props) => {
    const classes = (0,_style_styles__WEBPACK_IMPORTED_MODULE_5__.useStyles)();
    const { appName, shouldShowCloseButton, fetchLogs, handleClose } = props;
    const [logs, setLogs] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const handleFetchLogs = async () => {
        setError('');
        setIsLoading(true);
        try {
            const newLogs = await fetchLogs();
            setLogs(newLogs);
        }
        catch (error) {
            if (error instanceof Error) {
                setError(error.message);
            }
            else {
                setError('failed to retrieve logs from server');
            }
        }
        finally {
            setIsLoading(false);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (appName) {
            handleFetchLogs();
        }
    }, [appName, fetchLogs]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        prismjs__WEBPACK_IMPORTED_MODULE_2___default().highlightAll(); // Trigger Prism.js syntax highlighting
    });
    const errorResult = error && (
    // App container may have not started yet - just say no logs available in all cases.
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Common__WEBPACK_IMPORTED_MODULE_6__.ResultContainer, { viewType: 1 /* ViewType.MAIN */, resultType: 1 /* ResultType.SUCCESS */, title: 'There are no logs available', message: 'Refresh after some time' }));
    const logsResult = !errorResult && !isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'logs-container' },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'logs-content' },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("pre", { className: 'logs-pre' },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("code", { className: "language-log" }, logs))),
        shouldShowCloseButton && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Button, { style: { 'float': 'right' }, className: classes.primaryButton, variant: 'contained', size: 'small', onClick: handleClose }, "Close"))));
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'logs' },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", null,
            "Logs for ",
            appName),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Button, { className: classes.secondaryButton, variant: 'contained', size: 'small', onClick: handleFetchLogs, disabled: isLoading }, "Refresh"),
        errorResult,
        isLoading && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Common__WEBPACK_IMPORTED_MODULE_6__.LoadingView, { viewType: 1 /* ViewType.MAIN */ }),
        logsResult));
};


/***/ }),

/***/ "./lib/icons/icon.js":
/*!***************************!*\
  !*** ./lib/icons/icon.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   rocketIcon: () => (/* binding */ rocketIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_icons_rocket_solid_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../style/icons/rocket-solid.svg */ "./style/icons/rocket-solid.svg");


const rocketIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({ name: 'rocket', svgstr: _style_icons_rocket_solid_svg__WEBPACK_IMPORTED_MODULE_1__ });


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _notebookWidgets_TinyAppButtonWidget__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./notebookWidgets/TinyAppButtonWidget */ "./lib/notebookWidgets/TinyAppButtonWidget.js");
/* harmony import */ var _panelWidgets_TinyAppPanelWidget__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./panelWidgets/TinyAppPanelWidget */ "./lib/panelWidgets/TinyAppPanelWidget.js");
/* harmony import */ var _views_NewAppDir__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./views/NewAppDir */ "./lib/views/NewAppDir.js");
/* harmony import */ var _views_GenerateApp__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./views/GenerateApp */ "./lib/views/GenerateApp.js");
/* harmony import */ var _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/docmanager */ "webpack/sharing/consume/default/@jupyterlab/docmanager");
/* harmony import */ var _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _views_Preview__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./views/Preview */ "./lib/views/Preview.js");
/* harmony import */ var _views_PreviewLogs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./views/PreviewLogs */ "./lib/views/PreviewLogs.js");
/* harmony import */ var _views_Publish__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./views/Publish */ "./lib/views/Publish.js");
/* harmony import */ var _views_ListApps__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./views/ListApps */ "./lib/views/ListApps.js");
/* harmony import */ var _notebookWidgets_AppTypeSelector__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./notebookWidgets/AppTypeSelector */ "./lib/notebookWidgets/AppTypeSelector.js");
/* harmony import */ var _middleware__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./middleware */ "./lib/middleware.js");
/* harmony import */ var _icons_icon__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./icons/icon */ "./lib/icons/icon.js");















const WIDGET_TARGET = 'Notebook';
/* Main entry point into the extension
 this is where all commands are built and added to the notebook widget bar
 ----------------------------------------------------------------------------------------- */
const extension = {
    id: '@jupyterlab/tinyapp:plugin',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__.INotebookTracker, _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_3__.IDocumentManager],
    activate: async (app, tracker, docManager) => {
        const { commands, shell, docRegistry } = app;
        // new app directory
        commands.addCommand("newapp" /* CustomWidgetCommand.NEW_APP */, {
            execute: async (_) => (0,_views_NewAppDir__WEBPACK_IMPORTED_MODULE_4__.newAppDirExecutor)(commands, docManager),
            label: 'New App Directory',
            isEnabled: () => true
        });
        // generate app with ai
        commands.addCommand("generate" /* CustomWidgetCommand.GENERATE_APP */, {
            execute: async (args) => {
                if (!envVars.ai_enabled) {
                    console.warn('AI features are disabled. Cannot generate app.');
                    (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__.showDialog)({
                        title: 'AI Disabled',
                        body: 'AI features are currently disabled. Cannot generate app.',
                        buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__.Dialog.okButton({ label: 'OK' })]
                    });
                    return;
                }
                await (0,_views_GenerateApp__WEBPACK_IMPORTED_MODULE_5__.generateAppExecutor)(commands, tracker, docManager, args);
            },
            label: 'Generate App',
            isEnabled: () => envVars.ai_enabled
        });
        // list apps
        commands.addCommand("listapps" /* CustomWidgetCommand.LIST_APPS */, {
            execute: async (_) => (0,_views_ListApps__WEBPACK_IMPORTED_MODULE_6__.listAppsExecutor)(shell),
            label: 'Published Apps',
            isEnabled: () => true
        });
        // preview
        commands.addCommand("preview" /* CustomWidgetCommand.PREVIEW */, {
            execute: async (_) => (0,_views_Preview__WEBPACK_IMPORTED_MODULE_7__.previewExecutor)(tracker, shell),
            label: 'Preview App',
            isEnabled: () => true,
            iconClass: 'app-launcher-notebook-button-icon fas fa-drafting-compass'
        });
        // preview logs
        commands.addCommand("preview:logs" /* CustomWidgetCommand.PREVIEW_LOGS */, {
            execute: async (_) => (0,_views_PreviewLogs__WEBPACK_IMPORTED_MODULE_8__.previewLogsExecutor)(shell),
            label: 'Logs',
            isEnabled: () => true,
            iconClass: 'app-launcher-notebook-button-icon fas fa-book-open'
        });
        // publish
        commands.addCommand("publish" /* CustomWidgetCommand.PUBLISH */, {
            execute: async (_) => (0,_views_Publish__WEBPACK_IMPORTED_MODULE_9__.publishExecutor)(tracker, shell),
            label: 'Publish App',
            isEnabled: () => true,
            iconClass: 'app-launcher-notebook-button-icon fas fa-rocket'
        });
        // register notebook menu buttons
        const appTypeSelector = new _notebookWidgets_AppTypeSelector__WEBPACK_IMPORTED_MODULE_10__["default"](commands, tracker);
        const previewButton = new _notebookWidgets_TinyAppButtonWidget__WEBPACK_IMPORTED_MODULE_11__["default"](commands, "preview" /* CustomWidgetCommand.PREVIEW */);
        const previewLogsButton = new _notebookWidgets_TinyAppButtonWidget__WEBPACK_IMPORTED_MODULE_11__["default"](commands, "preview:logs" /* CustomWidgetCommand.PREVIEW_LOGS */);
        const publishButton = new _notebookWidgets_TinyAppButtonWidget__WEBPACK_IMPORTED_MODULE_11__["default"](commands, "publish" /* CustomWidgetCommand.PUBLISH */);
        docRegistry.addWidgetExtension(WIDGET_TARGET, publishButton);
        docRegistry.addWidgetExtension(WIDGET_TARGET, previewLogsButton);
        docRegistry.addWidgetExtension(WIDGET_TARGET, previewButton);
        docRegistry.addWidgetExtension(WIDGET_TARGET, appTypeSelector);
        var envVars = {
            ai_enabled: false,
        };
        try {
            envVars = await (0,_middleware__WEBPACK_IMPORTED_MODULE_12__.requestAPI)('get_env_vars', {
                method: 'GET'
            });
        }
        catch (e) {
            console.error('failed to get env vars from server', e);
        }
        // register left panel widget
        const appLauncherSideBarWidget = _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__.ReactWidget.create(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_panelWidgets_TinyAppPanelWidget__WEBPACK_IMPORTED_MODULE_13__.TinyAppPanelWidget, { commands: commands, envVars: envVars }));
        appLauncherSideBarWidget.id = 'app-launcher-sidebar-widget';
        appLauncherSideBarWidget.title.icon = _icons_icon__WEBPACK_IMPORTED_MODULE_14__.rocketIcon;
        appLauncherSideBarWidget.title.caption = 'Tiny Apps';
        app.shell.add(appLauncherSideBarWidget, 'left', { rank: 200 });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);


/***/ }),

/***/ "./lib/middleware.js":
/*!***************************!*\
  !*** ./lib/middleware.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createWebSocket: () => (/* binding */ createWebSocket),
/* harmony export */   requestAPI: () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


const API_NAMESPACE = 'tinyapp';
function createWebSocket() {
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, API_NAMESPACE, 'generate_app');
    const wsUrl = requestUrl.replace('http', 'ws');
    return new WebSocket(wsUrl);
}
/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}, timeout = 600000) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, API_NAMESPACE, endPoint);
    let response;
    try {
        response = await asyncCallWithTimeout(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings), timeout);
    }
    catch (error) {
        if (error instanceof TypeError) {
            throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
        }
        else if (error instanceof Error) {
            throw new Error('error making request: ' + error.message);
        }
        else {
            throw new Error('error making request: ' + JSON.stringify(error));
        }
    }
    const data = await response.json();
    if (!response.ok) {
        throw new Error(response.status + ': ' + data.message);
    }
    return data;
}
/**
 * Call an async function with a maximum time limit (in milliseconds) for the timeout
 * @param asyncPromise An asynchronous promise to resolve
 * @param timeLimit Time limit to attempt function in milliseconds
 * @returns Resolved promise for async function call, or an error if time limit reached
 */
const asyncCallWithTimeout = async (asyncPromise, timeLimit) => {
    let timeoutHandle;
    const timeoutPromise = new Promise((_resolve, reject) => {
        timeoutHandle = setTimeout(() => reject(new Error('async call timeout limit reached')), timeLimit);
    });
    return Promise.race([asyncPromise, timeoutPromise]).then(result => {
        clearTimeout(timeoutHandle);
        return result;
    });
};


/***/ }),

/***/ "./lib/notebookWidgets/AppTypeSelector.js":
/*!************************************************!*\
  !*** ./lib/notebookWidgets/AppTypeSelector.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__);



const INSERT_AFTER_WIDGET = 'spacer';
const appTypeToLabel = (appType) => {
    return appType.toString();
};
const AppTypeSelector = () => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.HTMLSelect, { "aria-label": "App Type", className: 'app-type-selector' },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "streamlit" /* AppType.STREAMLIT */ }, appTypeToLabel("streamlit" /* AppType.STREAMLIT */)),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "dash" /* AppType.DASH */ }, appTypeToLabel("dash" /* AppType.DASH */))));
};
class AppLauncherSelectorWidget {
    constructor(commands, tracker) {
        this.commands = commands;
        this.tracker = tracker;
    }
    createNew(panel, context) {
        const appTypeSelector = _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__.ReactWidget.create(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(AppTypeSelector, null));
        panel.toolbar.insertAfter(INSERT_AFTER_WIDGET, "", appTypeSelector);
        return appTypeSelector;
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppLauncherSelectorWidget);


/***/ }),

/***/ "./lib/notebookWidgets/TinyAppButtonWidget.js":
/*!****************************************************!*\
  !*** ./lib/notebookWidgets/TinyAppButtonWidget.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);

const INSERT_AFTER_WIDGET = 'spacer';
/*
TinyAppButtonWidget:
class wrapper for an extension button within the notebook widget

Note: each widget is added to the bar after the spacer. This means to order your
widgets 1, 2, 3 you will need to add them in order 3, 2, 1
 */
class TinyAppButtonWidget {
    constructor(commands, action) {
        this.commands = commands;
        this.action = action;
    }
    createNew(panel, context) {
        const button = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.CommandToolbarButton({
            commands: this.commands,
            id: this.action
        });
        panel.toolbar.insertAfter(INSERT_AFTER_WIDGET, this.action, button);
        return button;
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TinyAppButtonWidget);


/***/ }),

/***/ "./lib/panelWidgets/TinyAppPanelWidget.js":
/*!************************************************!*\
  !*** ./lib/panelWidgets/TinyAppPanelWidget.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TinyAppPanelWidget: () => (/* binding */ TinyAppPanelWidget)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/Button */ "./node_modules/@material-ui/core/esm/Button/Button.js");
/* harmony import */ var _style_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../style/styles */ "./lib/style/styles.js");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "webpack/sharing/consume/default/@material-ui/core/@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../style/theme */ "./lib/style/theme.js");
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-icons/rx */ "./node_modules/react-icons/rx/index.esm.js");






const TinyAppPanelWidget = (props) => {
    const classes = (0,_style_styles__WEBPACK_IMPORTED_MODULE_2__.useStyles)();
    const [promptTextInput, setPromptTextInput] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [uploadedImage, setUploadedImage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const handlePromptInputChange = (event) => {
        setPromptTextInput(event.target.value);
    };
    const handleImageChange = (event) => {
        var _a;
        const imageFile = (_a = event.target.files) === null || _a === void 0 ? void 0 : _a[0];
        if (imageFile) {
            // Validate the file size (less than 20 MB)
            const maxSize = 20 * 1024 * 1024; // 20 MB in bytes
            if (imageFile.size > maxSize) {
                alert("File is too large. Please select a file less than 20 MB.");
                return;
            }
            // Validate the file format (PNG, JPEG, GIF, or WEBP)
            const validFormats = ["image/png", "image/jpeg", "image/gif", "image/webp"];
            if (!validFormats.includes(imageFile.type)) {
                alert("Unsupported file format. Please select a PNG, JPEG, GIF, or WEBP file.");
                return;
            }
            // File reading and Data URL conversion
            const reader = new FileReader();
            reader.onload = (e) => {
                var _a;
                // Ensure the `result` is a string before calling `setUploadedImage`.
                if (typeof ((_a = e.target) === null || _a === void 0 ? void 0 : _a.result) === 'string') {
                    setUploadedImage(e.target.result);
                }
            };
            reader.onerror = (e) => {
                alert("Error reading file. Please try again.");
            };
            reader.readAsDataURL(imageFile);
        }
    };
    const { commands, envVars } = props;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.panelWrapper },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.ThemeProvider, { theme: _style_theme__WEBPACK_IMPORTED_MODULE_3__.theme },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "h5", component: "h3", align: "center", color: "textPrimary" },
                "Tiny App",
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("hr", null))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4__["default"], { variant: "contained", onClick: async () => {
                await commands.execute("newapp" /* CustomWidgetCommand.NEW_APP */);
            }, className: classes.panelButton },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: 'fas fa-plus' }),
            "\u00A0New App Directory"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4__["default"], { variant: "contained", onClick: async () => {
                await commands.execute("listapps" /* CustomWidgetCommand.LIST_APPS */);
            }, className: classes.panelButton },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: 'fas fa-user-alt' }),
            "\u00A0Published Apps"),
        envVars.ai_enabled ?
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4__["default"], { variant: "contained", onClick: async () => {
                        // pull this out as a func
                        await commands.execute("generate" /* CustomWidgetCommand.GENERATE_APP */, { prompt: promptTextInput, image: uploadedImage });
                    }, className: classes.panelButton },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_icons_rx__WEBPACK_IMPORTED_MODULE_5__.RxMagicWand, { size: 24 }),
                    "\u00A0Generate App"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.TextField
                // autoFocus={true} // TODO: remove this
                , { 
                    // autoFocus={true} // TODO: remove this
                    label: "Write your prompt", variant: "outlined", fullWidth: true, value: promptTextInput, onChange: handlePromptInputChange, className: classes.generateInput, multiline: true, rows: 2, maxRows: 4 }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `${classes.fileUploadContainer} ${classes.mt1}` },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { htmlFor: "file-upload", className: classes.mb1 }, "Mock Design"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { id: "file-upload", type: "file", accept: "image/*", onChange: handleImageChange }),
                    uploadedImage && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `${classes.mt1}` },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", { src: uploadedImage, alt: "Uploaded", style: { width: '50px', height: '50px' } }))))) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null)));
};


/***/ }),

/***/ "./lib/style/styles.js":
/*!*****************************!*\
  !*** ./lib/style/styles.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useStyles: () => (/* binding */ useStyles)
/* harmony export */ });
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/styles */ "webpack/sharing/consume/default/@material-ui/styles/@material-ui/styles");
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "webpack/sharing/consume/default/@material-ui/core/@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./theme */ "./lib/style/theme.js");



const useStyles = (0,_material_ui_styles__WEBPACK_IMPORTED_MODULE_0__.makeStyles)(() => (0,_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.createStyles)({
    formContainer: {
        padding: '5%'
    },
    panelWrapper: {
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        overflowY: 'auto',
        backgroundColor: 'white',
        alignItems: 'center'
    },
    appCard: {
        marginBottom: '30px',
        borderWidth: '2px'
    },
    listedAppsWrapper: {
        marginBottom: '30px',
        backgroundColor: 'white',
    },
    panelButton: {
        color: 'white !important',
        backgroundColor: 'rgb(0, 0, 243) !important',
        marginTop: '20px !important',
        padding: '15px !important',
        width: '100%',
    },
    generateInput: {
        // color: 'white !important',
        // backgroundColor: 'rgb(0, 0, 243) !important',
        marginTop: '20px !important',
        padding: '15px !important',
        width: '100%',
        // This is to keep the label from touching the left edge (prior to user input)
        '& .MuiInputLabel-outlined': {
            // Targeting the label of an outlined TextField
            marginLeft: _theme__WEBPACK_IMPORTED_MODULE_2__.theme.spacing(1),
            // Ensure this margin applies only when the label is shrunken
            '&.MuiInputLabel-shrink': {
                marginLeft: _theme__WEBPACK_IMPORTED_MODULE_2__.theme.spacing(1),
            },
        },
    },
    fileUploadContainer: {
        // padding: '15px !important',
        textAlign: 'left',
        marginLeft: '50px !important',
        '& label': {
            display: 'block',
            // marginBottom: theme.spacing(3), // or use a fixed value like '5px'
        },
        '& input': {
        // Add any specific styles for your file input here if needed
        },
    },
    mt3: {
        marginTop: _theme__WEBPACK_IMPORTED_MODULE_2__.theme.spacing(3), // Assuming mt-3 stands for margin-top: 3
    },
    mt1: {
        marginTop: _theme__WEBPACK_IMPORTED_MODULE_2__.theme.spacing(1),
    },
    mb3: {
        marginBottom: _theme__WEBPACK_IMPORTED_MODULE_2__.theme.spacing(3), // Assuming mt-3 stands for margin-top: 3
    },
    mb1: {
        marginBottom: _theme__WEBPACK_IMPORTED_MODULE_2__.theme.spacing(1),
    },
    mainView: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        top: '40%'
    },
    partialView: {
        marginTop: '10%'
    },
    successContainer: {
        textAlign: 'center',
        fontSize: '30px',
        color: _theme__WEBPACK_IMPORTED_MODULE_2__.theme.palette.text.primary
    },
    errorContainer: {
        textAlign: 'center',
        fontSize: '30px',
        color: 'rgb(189, 61, 61)'
    },
    valuePairContainer: {
        display: 'flex'
    },
    valuePairLabel: {
        color: 'rgb(109, 117, 129)',
    },
    valuePairValue: {
        color: 'rgb(27, 29, 32)',
    },
    primaryButton: {
        color: 'white !important',
        backgroundColor: 'rgb(0, 0, 243) !important',
    },
    secondaryButton: {
        color: 'rgb(0, 0, 243) !important',
        backgroundColor: 'white !important',
        border: '1px solid rgb(0, 0, 243)'
    },
    colorPrimary: {
        color: 'rgb(0, 0, 243)',
        backgroundColor: 'rgb(0, 0, 243)',
    },
    barColorPrimary: {
        color: 'rgb(219, 221, 225)',
        backgroundColor: 'rgb(219, 221, 225)'
    }
}));


/***/ }),

/***/ "./lib/style/theme.js":
/*!****************************!*\
  !*** ./lib/style/theme.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   theme: () => (/* binding */ theme)
/* harmony export */ });
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "./node_modules/@material-ui/core/esm/styles/createTheme.js");

const theme = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["default"])({
    palette: {
        primary: {
            main: 'rgb(0, 0, 243)'
        },
        secondary: {
            main: 'rgba(0, 0, 0, 0.54)'
        },
        text: {
            primary: 'rgba(0, 0, 0, .75)'
        }
    }
});


/***/ }),

/***/ "./lib/utils/common.js":
/*!*****************************!*\
  !*** ./lib/utils/common.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   delay: () => (/* binding */ delay),
/* harmony export */   getSelectedAppType: () => (/* binding */ getSelectedAppType),
/* harmony export */   makeRandomStr: () => (/* binding */ makeRandomStr)
/* harmony export */ });
const getSelectedAppType = (id) => {
    const currentWidget = document.getElementById(id);
    var selectorDiv;
    var selector;
    if (currentWidget != null) {
        selectorDiv = currentWidget.getElementsByClassName('app-type-selector')[0];
        selector = selectorDiv.getElementsByTagName('select')[0];
        return selector.options[selector.selectedIndex].value;
    }
    else {
        return "";
    }
};
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
const makeRandomStr = (len) => {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < len) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
        counter += 1;
    }
    return result;
};


/***/ }),

/***/ "./lib/views/GenerateApp.js":
/*!**********************************!*\
  !*** ./lib/views/GenerateApp.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   generateAppExecutor: () => (/* binding */ generateAppExecutor)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _middleware__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../middleware */ "./lib/middleware.js");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__);



var StreamDestination;
(function (StreamDestination) {
    StreamDestination["DESCRIPTION"] = "description";
    StreamDestination["CODE"] = "code";
    StreamDestination["REQUIREMENTS"] = "requirements";
    StreamDestination["UNDEFINED"] = "undefined";
})(StreamDestination || (StreamDestination = {}));
var StreamToken;
(function (StreamToken) {
    StreamToken["DESCRIPTION_START"] = "<<desc>>";
    StreamToken["DESCRIPTION_END"] = "<</desc>>";
    StreamToken["CODE_START"] = "<<code>>";
    StreamToken["CODE_END"] = "<</code>>";
    StreamToken["UNDEFINED"] = "undefined";
})(StreamToken || (StreamToken = {}));
const GenerateApp = async (commands, notebook, notebookPath, generateArgs) => {
    console.log("generating an app!");
    console.log("notebook panel is not null");
    // const notebook: Notebook = notebookPanel.content;
    const socket = (0,_middleware__WEBPACK_IMPORTED_MODULE_2__.createWebSocket)();
    socket.onopen = async () => {
        var _a, _b;
        console.log("WebSocket connection established");
        const requestData = {
            notebookPath: notebookPath,
            prompt: generateArgs.prompt,
            image: generateArgs.image
        };
        // Clear cells in notebook
        const numCells = (_a = notebook.model) === null || _a === void 0 ? void 0 : _a.sharedModel.cells.length;
        if (numCells) {
            (_b = notebook.model) === null || _b === void 0 ? void 0 : _b.sharedModel.deleteCellRange(0, numCells);
        }
        socket.send(JSON.stringify(requestData));
    };
    var streamDestination = StreamDestination.DESCRIPTION;
    socket.onmessage = async (event) => {
        switch (event.data) {
            case StreamToken.DESCRIPTION_START:
                streamDestination = StreamDestination.DESCRIPTION;
                const newIndex = notebook.activeCell ? notebook.activeCellIndex : 0;
                if (!notebook.model) {
                    return;
                }
                notebook.model.sharedModel.insertCell(newIndex, {
                    cell_type: 'markdown',
                    source: "# App Description \n",
                    metadata: notebook.notebookConfig.defaultCell === 'code'
                        ? {
                            // This is an empty cell created by user, thus is trusted
                            trusted: true
                        }
                        : {}
                });
                notebook.activeCellIndex = newIndex;
                break;
            case StreamToken.DESCRIPTION_END:
                console.log("found end of description. Stream destination is now none");
                // strip whitespace from active cell
                if (notebook.activeCell) {
                    notebook.activeCell.model.sharedModel.setSource(notebook.activeCell.model.sharedModel.getSource().trim());
                }
                streamDestination = StreamDestination.UNDEFINED;
                break;
            case StreamToken.CODE_START:
                streamDestination = StreamDestination.CODE;
                console.log("add and activate code cell");
                _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__.NotebookActions.insertBelow(notebook);
                break;
            case StreamToken.CODE_END:
                console.log("found end of code. Stream destination is now none");
                streamDestination = StreamDestination.UNDEFINED;
                // strip whitespace from active cell
                if (notebook.activeCell) {
                    notebook.activeCell.model.sharedModel.setSource(notebook.activeCell.model.sharedModel.getSource().replace(/^\s+|\s+$/g, '')); //.trim());
                }
                await commands.execute('docmanager:save');
                socket.close();
                break;
            // TODO: we could have a <<deps>> case here but we're handling it in python for now
            default:
                console.log("writing to cell: ", streamDestination);
                // TODO: consider when to access cell via notebook and notebook panel above
                if (notebook.activeCell) {
                    notebook.activeCell.model.sharedModel.setSource(notebook.activeCell.model.sharedModel.getSource() + event.data);
                }
        }
        ;
    };
    socket.onclose = () => {
        console.log("WebSocket connection closed");
    };
    socket.onerror = (error) => {
        console.error("WebSocket error:", error);
    };
};
const generateAppExecutor = async (commands, tracker, docManager, args) => {
    const currentWidget = tracker.currentWidget;
    if (!currentWidget) {
        (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showErrorMessage)("failed to generate app", "notebook must be opened & active");
        return;
    }
    const notebook = currentWidget.content;
    const notebookPath = currentWidget.context.path;
    if (!notebookPath.endsWith('.ipynb')) {
        (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showErrorMessage)("Selected file is not a notebook", "Please open a notebook file to generate an app");
        return;
    }
    await GenerateApp(commands, notebook, notebookPath, args);
};


/***/ }),

/***/ "./lib/views/ListApps.js":
/*!*******************************!*\
  !*** ./lib/views/ListApps.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   listAppsExecutor: () => (/* binding */ listAppsExecutor)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ "webpack/sharing/consume/default/@material-ui/core/@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _middleware__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../middleware */ "./lib/middleware.js");
/* harmony import */ var _style_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../style/styles */ "./lib/style/styles.js");
/* harmony import */ var _components_Common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/Common */ "./lib/components/Common.js");
/* harmony import */ var _components_Logs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/Logs */ "./lib/components/Logs.js");
/* harmony import */ var _components_AppCard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/AppCard */ "./lib/components/AppCard.js");








const listAppsExecutor = async (shell) => {
    const fetchApps = async () => {
        const result = await (0,_middleware__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('list_apps', { method: 'GET' });
        return result.data.apps;
    };
    const widget = _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget.create(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(AppsDisplay, { fetchApps: fetchApps }));
    widget.id = 'list-apps-widget';
    widget.title.iconClass = 'app-icon fas fa-user-alt';
    widget.title.label = 'Published Apps';
    widget.title.closable = true;
    shell.add(widget);
};
const AppsDisplay = (props) => {
    const classes = (0,_style_styles__WEBPACK_IMPORTED_MODULE_4__.useStyles)();
    const { fetchApps } = props;
    const [appsList, setAppsList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [logsIsOpen, setLogsIsOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [selectedAppName, setSelectedAppName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [selectedAppId, setSelectedAppId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const listedAppsRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const logsRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        // Function to handle clicks outside the component
        const handleClickOutside = (event) => {
            if (logsIsOpen &&
                event.button === 0 &&
                listedAppsRef.current && listedAppsRef.current.contains(event.target) &&
                logsRef.current && !logsRef.current.contains(event.target)) {
                setLogsIsOpen(false);
            }
        };
        if (logsIsOpen) {
            document.addEventListener('mousedown', handleClickOutside);
        }
        // Cleanup the event listener when the component unmounts
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [logsIsOpen]);
    const handleFetchApps = async () => {
        setError('');
        setIsLoading(true);
        try {
            const newAppsList = await fetchApps();
            setAppsList(newAppsList);
        }
        catch (error) {
            if (error instanceof Error) {
                setError(error.message);
            }
            else {
                setError('failed to retrieve apps from server');
            }
        }
        finally {
            setIsLoading(false);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        handleFetchApps();
    }, [fetchApps]);
    const handleDelete = (appId) => {
        const updatedAppsList = appsList.filter((app) => { var _a; return ((_a = app.appRelease) === null || _a === void 0 ? void 0 : _a.id) !== appId; });
        setAppsList(updatedAppsList);
    };
    const handleLogsButtonClick = (appName, appId) => {
        setSelectedAppName(appName);
        setSelectedAppId(appId);
        setLogsIsOpen(true);
    };
    const refreshButton = !isLoading && !error && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Button, { className: classes.secondaryButton, variant: 'contained', size: 'small', onClick: handleFetchApps, disabled: isLoading }, "Refresh"));
    const cardsList = appsList.map((app) => {
        var _a;
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_AppCard__WEBPACK_IMPORTED_MODULE_5__.AppCard, { key: (_a = app.appRelease) === null || _a === void 0 ? void 0 : _a.id, app: app, handleLogsButtonClick: handleLogsButtonClick, handleDelete: handleDelete }));
    });
    const cards = !isLoading && !error && (appsList.length > 0 ? cardsList : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Common__WEBPACK_IMPORTED_MODULE_6__.ResultContainer, { viewType: 1 /* ViewType.MAIN */, resultType: 1 /* ResultType.SUCCESS */, title: "You don't have any apps yet", message: 'You can publish an app from a notebook within an app directory' })));
    const fetchLogs = async () => {
        const result = await (0,_middleware__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('logs?app_name=' + selectedAppId, { method: 'GET' });
        return result.data.logs;
    };
    const logs = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `right-side-component ${logsIsOpen ? 'open' : ''}`, ref: logsRef },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Logs__WEBPACK_IMPORTED_MODULE_7__.LogsDisplay, { appName: selectedAppName, shouldShowCloseButton: true, fetchLogs: fetchLogs, handleClose: () => setLogsIsOpen(false) })));
    const loadingView = isLoading && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Common__WEBPACK_IMPORTED_MODULE_6__.LoadingView, { viewType: 1 /* ViewType.MAIN */ });
    const errorResult = error && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Common__WEBPACK_IMPORTED_MODULE_6__.ResultContainer, { viewType: 1 /* ViewType.MAIN */, resultType: 2 /* ResultType.ERROR */, title: 'Unable to load apps', message: 'Internal error occured' }));
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { ref: listedAppsRef },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'apps' },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null, refreshButton),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'cards-container' },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'cards-container2' },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.listedAppsWrapper }, cards))),
            errorResult,
            loadingView,
            logs)));
};


/***/ }),

/***/ "./lib/views/NewAppDir.js":
/*!********************************!*\
  !*** ./lib/views/NewAppDir.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   newAppDirExecutor: () => (/* binding */ newAppDirExecutor)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _middleware__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../middleware */ "./lib/middleware.js");



const createNewAppDir = async (commands, docManager, appDirectory) => {
    var result;
    try {
        result = await (0,_middleware__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('new_app_dir', {
            body: JSON.stringify({
                appDirectory: appDirectory
            }),
            method: 'POST'
        });
    }
    catch (e) {
        (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showErrorMessage)('failed to create app directory', e);
    }
    await commands.execute('filebrowser:go-to-path', { path: appDirectory });
    var kernelName = 'python3';
    const kernels = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.KernelAPI.listRunning();
    if (kernels.length > 100) {
        kernelName = kernels[0]['name'];
    }
    docManager.open(appDirectory + '/main.ipynb', 'default', { name: kernelName });
    // TODO save notebook
    // await commands.execute('docmanager:save')
    await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
        title: 'Successfully created app directory',
        body: 'initialized at ' + result.data.path,
        hasClose: false,
        buttons: [
            {
                label: 'Close',
                caption: 'Close',
                className: '',
                accept: true,
                displayType: 'default',
                ariaLabel: "",
                iconClass: "",
                iconLabel: "",
                actions: [],
            }
        ]
    });
};
const newAppDirExecutor = async (commands, docManager) => {
    const input = await _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.InputDialog.getText({ title: 'Enter App Directory Name' });
    const val = input.value;
    if (val !== null) {
        await createNewAppDir(commands, docManager, val);
    }
};


/***/ }),

/***/ "./lib/views/Preview.js":
/*!******************************!*\
  !*** ./lib/views/Preview.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   previewExecutor: () => (/* binding */ previewExecutor)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _middleware__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../middleware */ "./lib/middleware.js");
/* harmony import */ var _components_Common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Common */ "./lib/components/Common.js");
/* harmony import */ var _utils_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/common */ "./lib/utils/common.js");





let loadingWidget;
let errorWidget;
let widget;
let previewId;
const maxWaitTime = 1 * 60 * 1000; // 1 minutes in ms
const pingInterval = 1 * 1000; // 3 seconds in ms
// pings the app url
const ping = async (url) => {
    return new Promise(resolve => {
        (0,_middleware__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('ping', {
            body: JSON.stringify({
                url: url
            }),
            method: 'POST'
        })
            .then(result => result.data)
            .then(result => resolve(result.ok));
    });
};
const loadingTimeout = (t0, maxMilliseconds) => {
    const tn = new Date();
    const timeDeltaMilliseconds = tn.getTime() - t0.getTime();
    return timeDeltaMilliseconds > maxMilliseconds;
};
const makeTimeoutError = () => {
    const t = new Date(maxWaitTime);
    const timeFormat = `${t.getMinutes()}m ${t.getSeconds()}s`;
    return new Error(`loading preview timed out after ${timeFormat}`);
};
const previewExecutor = async (tracker, shell) => {
    const previewIdLocal = (0,_utils_common__WEBPACK_IMPORTED_MODULE_3__.makeRandomStr)(7);
    previewId = previewIdLocal;
    if (loadingWidget) {
        loadingWidget.close();
    }
    if (errorWidget) {
        errorWidget.close();
    }
    if (widget) {
        widget.close();
    }
    loadingWidget = _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget.create(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Common__WEBPACK_IMPORTED_MODULE_4__.LoadingView, { viewType: 1 /* ViewType.MAIN */ }));
    loadingWidget.id = 'preview-widget-loading';
    loadingWidget.title.label = 'Loading App Preview';
    loadingWidget.title.iconClass = 'app-icon fas fa-clock';
    loadingWidget.title.closable = true;
    shell.add(loadingWidget);
    var appType = "";
    var notebookPath = "";
    if (tracker.currentWidget == null) {
        appType = (0,_utils_common__WEBPACK_IMPORTED_MODULE_3__.getSelectedAppType)("");
    }
    else {
        appType = (0,_utils_common__WEBPACK_IMPORTED_MODULE_3__.getSelectedAppType)(tracker.currentWidget.id);
        notebookPath = tracker.currentWidget.context.path;
    }
    var result;
    try {
        result = await (0,_middleware__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('preview', {
            body: JSON.stringify({
                notebookPath: notebookPath,
                appType: appType,
            }),
            method: 'POST'
        });
        // ping url until it's up
        // also set timer for timeout
        const t0 = new Date();
        let ok = false;
        while (!ok) {
            if (loadingTimeout(t0, maxWaitTime)) {
                throw makeTimeoutError();
            }
            ok = await ping(result.data.appURL);
            console.log('ready: ' + ok.toString());
            await (0,_utils_common__WEBPACK_IMPORTED_MODULE_3__.delay)(pingInterval);
        }
        console.log('successfully loaded application in preview mode');
    }
    catch (error) {
        console.error('error while creating preview app:', error);
        if (previewIdLocal == previewId) {
            loadingWidget.close();
            errorWidget = _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget.create(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Common__WEBPACK_IMPORTED_MODULE_4__.ResultContainer, { viewType: 1 /* ViewType.MAIN */, resultType: 2 /* ResultType.ERROR */, title: 'Error loading app preview', message: 'Please check logs for details' }));
            errorWidget.id = 'preview-widget-error';
            errorWidget.title.iconClass = 'error-icon fas fa-exclamation-circle';
            errorWidget.title.label = 'Error';
            errorWidget.title.closable = true;
            shell.add(errorWidget);
        }
        return;
    }
    // remove loading widget and add the iframe widget
    // TODO if log widget exists, new widget pushes it to right - need to fix.
    if (previewIdLocal == previewId) {
        loadingWidget.close();
        widget = _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget.create(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Common__WEBPACK_IMPORTED_MODULE_4__.IframeContainer, { url: result.data.appURL, title: "local-app" }));
        widget.id = 'preview-widget';
        widget.title.label = `App Preview`;
        widget.title.iconClass = 'app-icon fas fa-rocket';
        widget.title.closable = true;
        shell.add(widget);
    }
};


/***/ }),

/***/ "./lib/views/PreviewLogs.js":
/*!**********************************!*\
  !*** ./lib/views/PreviewLogs.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   previewLogsExecutor: () => (/* binding */ previewLogsExecutor)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Logs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/Logs */ "./lib/components/Logs.js");
/* harmony import */ var _middleware__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../middleware */ "./lib/middleware.js");




let previewLogsWidget;
const fetchPreviewLogs = async () => {
    const result = await (0,_middleware__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('preview_logs', { method: 'GET' });
    return result.data.logs;
};
const previewLogsExecutor = async (shell) => {
    if (previewLogsWidget) {
        previewLogsWidget.close();
    }
    previewLogsWidget = _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget.create(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Logs__WEBPACK_IMPORTED_MODULE_3__.LogsDisplay, { fetchLogs: fetchPreviewLogs, shouldShowCloseButton: false, appName: 'App Preview', handleClose: () => { } }));
    previewLogsWidget.id = 'logs-for-app-preview-widget';
    previewLogsWidget.title.iconClass = 'app-icon fas fa-user-alt';
    previewLogsWidget.title.label = 'Logs for App Preview';
    previewLogsWidget.title.closable = true;
    shell.add(previewLogsWidget);
};


/***/ }),

/***/ "./lib/views/Publish.js":
/*!******************************!*\
  !*** ./lib/views/Publish.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   publishExecutor: () => (/* binding */ publishExecutor)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/Common */ "./lib/components/Common.js");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/styles */ "webpack/sharing/consume/default/@material-ui/styles/@material-ui/styles");
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_styles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _style_theme__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../style/theme */ "./lib/style/theme.js");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core */ "webpack/sharing/consume/default/@material-ui/core/@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _middleware__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../middleware */ "./lib/middleware.js");
/* harmony import */ var _style_styles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../style/styles */ "./lib/style/styles.js");
/* harmony import */ var _utils_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils/common */ "./lib/utils/common.js");










const publishExecutor = async (tracker, shell) => {
    var appType = "";
    var notebookPath = "";
    if (tracker.currentWidget != null) {
        appType = (0,_utils_common__WEBPACK_IMPORTED_MODULE_5__.getSelectedAppType)(tracker.currentWidget.id);
        notebookPath = tracker.currentWidget.context.path;
    }
    const widget = _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget.create(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(PublishForm, { notebookPath: notebookPath, appType: appType }));
    widget.id = 'publish-widget';
    widget.title.iconClass = 'app-icon fas fa-rocket';
    widget.title.label = `Publish ${_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.PathExt.basename(notebookPath, '.ipynb')}`;
    widget.title.closable = true;
    shell.add(widget);
};
const successMessage = 'You can launch view your app from the "Published Apps" button in the side panel';
const PublishForm = (props) => {
    const classes = (0,_style_styles__WEBPACK_IMPORTED_MODULE_6__.useStyles)();
    const { notebookPath, appType } = props;
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [showResult, setShowResult] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [resultType, setResultType] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0 /* ResultType.NULL */);
    const [title, setTitle] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const timestamp = new Date().getTime();
    const notebookName = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.PathExt.basename(notebookPath);
    const resultContainer = showResult && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Common__WEBPACK_IMPORTED_MODULE_7__.ResultContainer, { title: title, message: message, viewType: 0 /* ViewType.PARTIAL */, resultType: resultType }));
    const loadingView = isLoading && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Common__WEBPACK_IMPORTED_MODULE_7__.LoadingView, { viewType: 0 /* ViewType.PARTIAL */ });
    const submitHandler = async () => {
        setShowResult(false);
        setIsLoading(true);
        const appTitle = document.getElementById(`appTitle-${timestamp}`).value;
        const appDescription = document.getElementById(`appDescription-${timestamp}`).value;
        await (0,_middleware__WEBPACK_IMPORTED_MODULE_8__.requestAPI)('publish', {
            body: JSON.stringify({
                notebookPath: notebookPath,
                appTitle: appTitle,
                appDescription: appDescription,
                appType: appType,
            }),
            method: 'POST'
        })
            .then(result => result.data)
            .then(result => {
            setResultType(1 /* ResultType.SUCCESS */);
            setTitle('Your app has been published');
            setMessage(successMessage);
        })
            .catch((error) => {
            setResultType(2 /* ResultType.ERROR */);
            setTitle('Error publishing your app');
            setMessage(error.toString());
        })
            .finally(() => {
            setIsLoading(false);
            setShowResult(true);
        });
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.formContainer },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_styles__WEBPACK_IMPORTED_MODULE_3__.ThemeProvider, { theme: _style_theme__WEBPACK_IMPORTED_MODULE_9__.theme },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Typography, { component: "h1", variant: "h4", color: "textPrimary" },
                "Publish ",
                notebookName),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("br", null),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.FormControl, { fullWidth: true },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Common__WEBPACK_IMPORTED_MODULE_7__.StyledTextInputField, { id: "notebookPath", disabled: true, label: "Notebook Path", value: notebookPath })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.FormControl, { fullWidth: true },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Common__WEBPACK_IMPORTED_MODULE_7__.StyledTextInputField, { id: `appTitle-${timestamp}`, label: "App Title", disabled: isLoading })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.FormControl, { fullWidth: true },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Common__WEBPACK_IMPORTED_MODULE_7__.StyledTextInputField, { id: `appDescription-${timestamp}`, label: "App Description", disabled: isLoading }))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Button, { disabled: isLoading, variant: "contained", color: "primary", onClick: submitHandler }, "Publish")),
        loadingView,
        resultContainer));
};


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./style/base.css":
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \**************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
    See the JupyterLab Developer Guide for useful CSS Patterns:

    https://jupyterlab.readthedocs.io/en/stable/developer/css.html
*/

/* PrismJS 1.29.0
https://prismjs.com/download.html#themes=prism&languages=log */
code[class*=language-],pre[class*=language-]{color:#000;background:0 0;text-shadow:0 1px #fff;font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace;font-size:1em;text-align:left;white-space:pre;word-spacing:normal;word-break:normal;word-wrap:normal;line-height:1.5;-moz-tab-size:4;-o-tab-size:4;tab-size:4;-webkit-hyphens:none;-moz-hyphens:none;-ms-hyphens:none;hyphens:none}code[class*=language-] ::-moz-selection,code[class*=language-]::-moz-selection,pre[class*=language-] ::-moz-selection,pre[class*=language-]::-moz-selection{text-shadow:none;background:#b3d4fc}code[class*=language-] ::selection,code[class*=language-]::selection,pre[class*=language-] ::selection,pre[class*=language-]::selection{text-shadow:none;background:#b3d4fc}@media print{code[class*=language-],pre[class*=language-]{text-shadow:none}}pre[class*=language-]{padding:1em;margin:.5em 0;overflow:auto}:not(pre)>code[class*=language-],pre[class*=language-]{background:#f5f2f0}:not(pre)>code[class*=language-]{padding:.1em;border-radius:.3em;white-space:normal}.token.cdata,.token.comment,.token.doctype,.token.prolog{color:#708090}.token.punctuation{color:#999}.token.namespace{opacity:.7}.token.boolean,.token.constant,.token.deleted,.token.number,.token.property,.token.symbol,.token.tag{color:#905}.token.attr-name,.token.builtin,.token.char,.token.inserted,.token.selector,.token.string{color:#690}.language-css .token.string,.style .token.string,.token.entity,.token.operator,.token.url{color:#9a6e3a;background:hsla(0,0%,100%,.5)}.token.atrule,.token.attr-value,.token.keyword{color:#07a}.token.class-name,.token.function{color:#dd4a68}.token.important,.token.regex,.token.variable{color:#e90}.token.bold,.token.important{font-weight:700}.token.italic{font-style:italic}.token.entity{cursor:help}

.apps {
  height: calc(100vh - 4px);
  padding-top: 20px;
  padding-left: 60px;
  padding-right: 60px;
}

.cards-container {
  padding-top: 20px;
  height: calc(100vh - 190px);
}

.cards-container2 {
  height: 100%;
  overflow-y: auto;
}

.logs {
  padding-left: 20px;
  padding-right: 20px;
  padding-top: 10px;
}

.logs-container {
  padding-top: 10px;
  width: calc(100% - 0px);
  height: calc(100vh - 215px);
  position: relative;
}

.logs-content {
  height: 90%;
  padding-bottom: 20px;
}

.logs-pre {
  height: 95%
}

#list-apps-widget {
  padding-bottom: 31px;
}

.right-side-component {
  position: fixed;
  top: 0;
  right: -100%;
  width: 80%;
  height: 100%;
  background-color: #fff;
  box-shadow: -5px 0 10px rgba(0, 0, 0, 0.2);
  transition: right 0.3s ease;
  z-index: 1000;
}

.right-side-component.open {
  right: 0;
}`, "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAAA;;;;CAIC;;AAED;8DAC8D;AAC9D,6CAA6C,UAAU,CAAC,cAAc,CAAC,sBAAsB,CAAC,iEAAiE,CAAC,aAAa,CAAC,eAAe,CAAC,eAAe,CAAC,mBAAmB,CAAC,iBAAiB,CAAC,gBAAgB,CAAC,eAAe,CAAC,eAAe,CAAC,aAAa,CAAC,UAAU,CAAC,oBAAoB,CAAC,iBAAiB,CAAC,gBAAgB,CAAC,YAAY,CAAC,4JAA4J,gBAAgB,CAAC,kBAAkB,CAAC,wIAAwI,gBAAgB,CAAC,kBAAkB,CAAC,aAAa,6CAA6C,gBAAgB,CAAC,CAAC,sBAAsB,WAAW,CAAC,aAAa,CAAC,aAAa,CAAC,uDAAuD,kBAAkB,CAAC,iCAAiC,YAAY,CAAC,kBAAkB,CAAC,kBAAkB,CAAC,yDAAyD,aAAa,CAAC,mBAAmB,UAAU,CAAC,iBAAiB,UAAU,CAAC,qGAAqG,UAAU,CAAC,0FAA0F,UAAU,CAAC,0FAA0F,aAAa,CAAC,6BAA6B,CAAC,+CAA+C,UAAU,CAAC,kCAAkC,aAAa,CAAC,8CAA8C,UAAU,CAAC,6BAA6B,eAAe,CAAC,cAAc,iBAAiB,CAAC,cAAc,WAAW;;AAE5vD;EACE,yBAAyB;EACzB,iBAAiB;EACjB,kBAAkB;EAClB,mBAAmB;AACrB;;AAEA;EACE,iBAAiB;EACjB,2BAA2B;AAC7B;;AAEA;EACE,YAAY;EACZ,gBAAgB;AAClB;;AAEA;EACE,kBAAkB;EAClB,mBAAmB;EACnB,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;EACjB,uBAAuB;EACvB,2BAA2B;EAC3B,kBAAkB;AACpB;;AAEA;EACE,WAAW;EACX,oBAAoB;AACtB;;AAEA;EACE;AACF;;AAEA;EACE,oBAAoB;AACtB;;AAEA;EACE,eAAe;EACf,MAAM;EACN,YAAY;EACZ,UAAU;EACV,YAAY;EACZ,sBAAsB;EACtB,0CAA0C;EAC1C,2BAA2B;EAC3B,aAAa;AACf;;AAEA;EACE,QAAQ;AACV","sourcesContent":["/*\n    See the JupyterLab Developer Guide for useful CSS Patterns:\n\n    https://jupyterlab.readthedocs.io/en/stable/developer/css.html\n*/\n\n/* PrismJS 1.29.0\nhttps://prismjs.com/download.html#themes=prism&languages=log */\ncode[class*=language-],pre[class*=language-]{color:#000;background:0 0;text-shadow:0 1px #fff;font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace;font-size:1em;text-align:left;white-space:pre;word-spacing:normal;word-break:normal;word-wrap:normal;line-height:1.5;-moz-tab-size:4;-o-tab-size:4;tab-size:4;-webkit-hyphens:none;-moz-hyphens:none;-ms-hyphens:none;hyphens:none}code[class*=language-] ::-moz-selection,code[class*=language-]::-moz-selection,pre[class*=language-] ::-moz-selection,pre[class*=language-]::-moz-selection{text-shadow:none;background:#b3d4fc}code[class*=language-] ::selection,code[class*=language-]::selection,pre[class*=language-] ::selection,pre[class*=language-]::selection{text-shadow:none;background:#b3d4fc}@media print{code[class*=language-],pre[class*=language-]{text-shadow:none}}pre[class*=language-]{padding:1em;margin:.5em 0;overflow:auto}:not(pre)>code[class*=language-],pre[class*=language-]{background:#f5f2f0}:not(pre)>code[class*=language-]{padding:.1em;border-radius:.3em;white-space:normal}.token.cdata,.token.comment,.token.doctype,.token.prolog{color:#708090}.token.punctuation{color:#999}.token.namespace{opacity:.7}.token.boolean,.token.constant,.token.deleted,.token.number,.token.property,.token.symbol,.token.tag{color:#905}.token.attr-name,.token.builtin,.token.char,.token.inserted,.token.selector,.token.string{color:#690}.language-css .token.string,.style .token.string,.token.entity,.token.operator,.token.url{color:#9a6e3a;background:hsla(0,0%,100%,.5)}.token.atrule,.token.attr-value,.token.keyword{color:#07a}.token.class-name,.token.function{color:#dd4a68}.token.important,.token.regex,.token.variable{color:#e90}.token.bold,.token.important{font-weight:700}.token.italic{font-style:italic}.token.entity{cursor:help}\n\n.apps {\n  height: calc(100vh - 4px);\n  padding-top: 20px;\n  padding-left: 60px;\n  padding-right: 60px;\n}\n\n.cards-container {\n  padding-top: 20px;\n  height: calc(100vh - 190px);\n}\n\n.cards-container2 {\n  height: 100%;\n  overflow-y: auto;\n}\n\n.logs {\n  padding-left: 20px;\n  padding-right: 20px;\n  padding-top: 10px;\n}\n\n.logs-container {\n  padding-top: 10px;\n  width: calc(100% - 0px);\n  height: calc(100vh - 215px);\n  position: relative;\n}\n\n.logs-content {\n  height: 90%;\n  padding-bottom: 20px;\n}\n\n.logs-pre {\n  height: 95%\n}\n\n#list-apps-widget {\n  padding-bottom: 31px;\n}\n\n.right-side-component {\n  position: fixed;\n  top: 0;\n  right: -100%;\n  width: 80%;\n  height: 100%;\n  background-color: #fff;\n  box-shadow: -5px 0 10px rgba(0, 0, 0, 0.2);\n  transition: right 0.3s ease;\n  z-index: 1000;\n}\n\n.right-side-component.open {\n  right: 0;\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./style/base.css":
/*!************************!*\
  !*** ./style/base.css ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./base.css */ "./node_modules/css-loader/dist/cjs.js!./style/base.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./style/icons/rocket-solid.svg":
/*!**************************************!*\
  !*** ./style/icons/rocket-solid.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"1em\" viewBox=\"0 0 512 512\"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><style>svg{fill:#616161}</style><path d=\"M156.6 384.9L125.7 354c-8.5-8.5-11.5-20.8-7.7-32.2c3-8.9 7-20.5 11.8-33.8L24 288c-8.6 0-16.6-4.6-20.9-12.1s-4.2-16.7 .2-24.1l52.5-88.5c13-21.9 36.5-35.3 61.9-35.3l82.3 0c2.4-4 4.8-7.7 7.2-11.3C289.1-4.1 411.1-8.1 483.9 5.3c11.6 2.1 20.6 11.2 22.8 22.8c13.4 72.9 9.3 194.8-111.4 276.7c-3.5 2.4-7.3 4.8-11.3 7.2v82.3c0 25.4-13.4 49-35.3 61.9l-88.5 52.5c-7.4 4.4-16.6 4.5-24.1 .2s-12.1-12.2-12.1-20.9V380.8c-14.1 4.9-26.4 8.9-35.7 11.9c-11.2 3.6-23.4 .5-31.8-7.8zM384 168a40 40 0 1 0 0-80 40 40 0 1 0 0 80z\"/></svg>";

/***/ })

}]);
//# sourceMappingURL=lib_index_js.6c71de149e78484a07b4.js.map